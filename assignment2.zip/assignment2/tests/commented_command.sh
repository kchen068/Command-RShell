#!/bin/sh

#This has a series of multiple command tests w/ comments#

../bin/rshell < commented_command_test