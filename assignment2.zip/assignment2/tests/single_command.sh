#!/bin/sh

#This has a series of single command tests w/o comments#

../bin/rshell < single_command_test