#!/bin/sh

#This has a series of exit command tests#

../bin/rshell < exit_test