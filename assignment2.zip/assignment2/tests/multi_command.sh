#!/bin/sh

#This has a series of multiple command tests w/o comments#

../bin/rshell < multi_command_test